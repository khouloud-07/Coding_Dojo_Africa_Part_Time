function logout(element) {
    element.innerText = "logout";
}
function hide(element) {
    element.remove();
}
