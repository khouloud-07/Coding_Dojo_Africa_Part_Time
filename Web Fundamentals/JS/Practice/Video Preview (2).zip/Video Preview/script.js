console.log("page loaded...");
function play(element) {
    alert("mouseover");    
}
    
function pause(element) {
    alert("mouseout");    
}

